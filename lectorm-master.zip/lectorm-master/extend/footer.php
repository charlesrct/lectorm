<footer class="android-footer mdl-mega-footer">
  <div class="mdl-mega-footer--top-section">
    <!-- REDES SOCAILES  -->
    <div class="mdl-mega-footer--left-section">
      <!-- iet -->
      <a href="http://www.ietfranciscomanzanerah.edu.co/" target="_blank">
        <button class="mdl-button  mdl-button--fab">
          <img src="../img/logomini.png" width="70%">
        </button>
      </a>
      &nbsp;
      <!-- Facebook -->
      <a href="https://www.facebook.com/IET-Francisco-Manzanera-Henr%C3%ADquez-Fanpage-366619123833810/" target="_blank">
        <button class="mdl-button  mdl-button--fab">
          <img src="../img/icons8-facebook-old.svg">
        </button>
      </a>
      &nbsp;
      <!-- Youtube -->
      <a href="https://www.youtube.com/channel/UCwS5QrR3h4CzHvSMzZ7qC5Q/videos?view=0&sort=dd&shelf_id=0" target="_blank">
        <button class="mdl-button  mdl-button--fab">
          <img src="../img/icons8-youtube.svg">
        </button>
      </a>
      &nbsp;
    </div>
    <!-- FIN REDES SOCAILES  -->

    <div class="mdl-mega-footer--right-section">
      <a class="mdl-typography--font-light" href="#top">
        Regresar al inicio.
        <i class="material-icons">expand_less</i>
      </a>
    </div>
  </div>

  <div class="mdl-mega-footer--middle-section">
    <p class="mdl-typography--font-light">©2019 Charles Torres Ing. Electrónico Mg. Ingeniería de Software<br>
      Docente Tecnología e Informática IET Francisco Manzanera Henríquez
    </p>
  </div>

  <div class="mdl-mega-footer--bottom-section">
    <a class="android-link android-link-menu mdl-typography--font-light" id="version-dropdown">
      <a class="android-link mdl-typography--font-light" href="">Politicas de privacidad</a>
  </div>
</footer>
</div>
</div>
<?php
// include '../extend/scripts.php';
?>

<!-- </body> -->

<!-- </html> -->