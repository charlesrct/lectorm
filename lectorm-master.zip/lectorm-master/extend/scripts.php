<script src="../js/jquery-3.4.1.min.js"></script>
<script src="../js/material.min.js"></script>
<script src="../js/jquery.validate.min.js"></script>
<script src="../js/additional-methods.min.js"></script>
<script src="../js/validateES.js"></script>