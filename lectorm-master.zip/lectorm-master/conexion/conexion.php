<?php
date_default_timezone_set('America/Bogota');
$con = new mysqli('localhost', 'root', '', 'lectorm');
